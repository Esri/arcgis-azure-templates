﻿Configuration FileShareConfiguration
{
	param(
        [Parameter(Mandatory=$true)]
        [ValidateNotNullorEmpty()]
        [System.Management.Automation.PSCredential]
        $ServiceCredential

        ,[Parameter(Mandatory=$true)]
        [ValidateNotNullorEmpty()]
        [System.Management.Automation.PSCredential]
        $SiteAdministratorCredential

		,[Parameter(Mandatory=$false)]
        [System.Management.Automation.PSCredential]
        $MachineAdministratorCredential
       
        ,[Parameter(Mandatory=$false)]
        [System.String]
        $PortalEndpoint

        ,[Parameter(Mandatory=$false)]
        [System.String]
        $ServerEndpoint

        ,[Parameter(Mandatory=$false)]
        [System.Management.Automation.PSCredential]
        $SelfSignedSSLCertificatePassword

        ,[Parameter(Mandatory=$false)]
        [System.String]
        $PortalMachineNames
        
        ,[Parameter(Mandatory=$false)]
        [System.String]
        $ServerMachineNames

        ,[Parameter(Mandatory=$true)]
        [System.String]
        $ExternalDNSHostName    

        ,[Parameter(Mandatory=$false)]
        [System.Int32]
        $OSDiskSize = 0

         ,[Parameter(Mandatory=$false)]
        [System.String]
        $EnableDataDisk  

        ,[Parameter(Mandatory=$false)]
        [System.String]
        $FileShareName = 'fileshare' 

        ,[Parameter(Mandatory=$false)]
        [System.String]
        $DebugMode
    )
    
    Import-DscResource -Name MSFT_xDisk
    Import-DscResource -Name MSFT_xSmbShare
    Import-DscResource -Name ArcGIS_Disk
    
    $FileShareHostName = $env:ComputerName
    $FolderName = $ExternalDNSHostName.Substring(0, $ExternalDNSHostName.IndexOf('.')).ToLower()
    $FileShareLocalPath = (Join-Path $env:SystemDrive $FileShareName)  
    $CertsFolder = Join-Path $FileShareLocalPath 'Certs'
    if(-not(Test-Path $CertsFolder)){
        New-Item -Path $CertsFolder -ItemType directory -ErrorAction Stop
    }
    $IsDebugMode = $DebugMode -ieq 'true'

    function Create-SelfSignedCertificateWithSANs
    {
        param(
            [string]
            $CertificateFilePath,

            [string]
            $CertificatePassword,

            [string]
            $Endpoint,

            $Nodes
        )
        $DnsNames = @($Endpoint)
        if($Nodes) {
            $Nodes | ForEach-Object { $DnsNames += Get-FQDN $_ }
        }
        Write-Verbose "Generating a self signed certificate with the DNS names $($DnsNames -join ',') for the Endpoint $($EndPoint)"
        if([Environment]::OSVersion.Version.Major -ge 10) {
            $Cert = New-SelfSignedCertificate -DnsName @($DnsNames) -CertStoreLocation Cert:\LocalMachine\My -NotBefore ([System.DateTime]::UtcNow).AddDays(-5) -NotAfter ([System.DateTime]::UtcNow).AddYears(5) 
        }else {
            $Cert = New-SelfSignedCertificate -DnsName @($DnsNames) -CertStoreLocation Cert:\LocalMachine\My 
        }
        Write-Verbose "Saving (exporting) file to $CertificateFilePath"
        Export-PfxCertificate -Force -Password (ConvertTo-SecureString -AsPlainText $CertificatePassword -Force) -FilePath $CertificateFilePath -Cert "Cert:\LocalMachine\My\$($Cert.Thumbprint)"   
        Remove-Item "Cert:\LocalMachine\My\$($Cert.Thumbprint)" -Force -ErrorAction Ignore
        Write-Verbose "Saved cert with thumbprint $($Cert.Thumbprint) file to $CertificateFilePath"   
    }

    if($PortalEndpoint -and $SelfSignedSSLCertificatePassword -and $PortalMachineNames -and ($SelfSignedSSLCertificatePassword.GetNetworkCredential().Password -ine 'Placeholder')) {
        $OutputCertFilePath = Join-Path $CertsFolder 'SSLCertificateForPortal.pfx'
        if(-not(Test-Path $OutputCertFilePath)) {
            Create-SelfSignedCertificateWithSANs -CertificateFilePath $OutputCertFilePath -CertificatePassword $SelfSignedSSLCertificatePassword.GetNetworkCredential().Password -Endpoint $PortalEndpoint -Nodes ($PortalMachineNames -split ',')
        }
    }
    if($ServerEndpoint -and $SelfSignedSSLCertificatePassword -and $ServerMachineNames -and ($SelfSignedSSLCertificatePassword.GetNetworkCredential().Password -ine 'Placeholder')) {
        $OutputCertFilePath = Join-Path $CertsFolder 'SSLCertificateForServer.pfx'
        if(-not(Test-Path $OutputCertFilePath)) {
            Create-SelfSignedCertificateWithSANs -CertificateFilePath (Join-Path $CertsFolder 'SSLCertificateForServer.pfx') -CertificatePassword $SelfSignedSSLCertificatePassword.GetNetworkCredential().Password -Endpoint $ServerEndpoint -Nodes ($ServerMachineNames -split ',')
        }
    }

	Node localhost
	{   
        if($OSDiskSize -gt 0) 
        {
            ArcGIS_Disk OSDiskSize
            {
                DriveLetter = ($env:SystemDrive -replace ":" )
                SizeInGB    = $OSDiskSize
            }
        }
        
        if($EnableDataDisk -ieq 'true')
        {
            xDisk DataDisk
            {
                DiskNumber  =  2
                DriveLetter = 'F'
            }
        }

		User ArcGIS_RunAsAccount
        {
            UserName       = $ServiceCredential.UserName
            Password       = $ServiceCredential
            FullName       = 'ArcGIS Service Account'
            Ensure         = 'Present'
            PasswordChangeRequired = $false
            PasswordNeverExpires = $true
        }
        
        File FileShareLocationPath
		{
			Type						= 'Directory'
			DestinationPath				= $FileShareLocalPath
			Ensure						= 'Present'
			Force						= $true
		}        

        File ContentDirectoryLocationPath
		{
			Type						= 'Directory'
			DestinationPath				= (Join-Path $FileShareLocalPath "$FolderName/portal/content")
			Ensure						= 'Present'
			Force						= $true
		}

        $DataStoreBackupsLocalPath = (Join-Path $FileShareLocalPath "$FolderName/datastore/dbbackups")
        File DataStoreBackupsLocationPath
		{
			Type						= 'Directory'
			DestinationPath				= $DataStoreBackupsLocalPath
			Ensure						= 'Present'
			Force						= $true
		}

		$Accounts = @('NT AUTHORITY\SYSTEM')
		if($ServiceCredential) { $Accounts += $ServiceCredential.GetNetworkCredential().UserName }
		if($MachineAdministratorCredential -and ($MachineAdministratorCredential.GetNetworkCredential().UserName -ine 'Placeholder') -and ($MachineAdministratorCredential.GetNetworkCredential().UserName -ine $ServiceCredential.GetNetworkCredential().UserName)) { $Accounts += $MachineAdministratorCredential.GetNetworkCredential().UserName }
        xSmbShare FileShare 
		{ 
			Ensure						= 'Present' 
			Name						= $FileShareName
			Path						= $FileShareLocalPath
			FullAccess					= $Accounts
			DependsOn					= @('[File]FileShareLocationPath', '[User]ArcGIS_RunAsAccount')          
		}
	}
}