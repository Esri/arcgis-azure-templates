function Get-TargetResource
{
    [CmdletBinding()]
	[OutputType([System.Collections.Hashtable])]
	param
	(
        [parameter(Mandatory = $true)]
        [System.String]
        $SharedLocation,

        [parameter(Mandatory = $true)]
		[ValidateSet("FileSystem","Azure")]
        [System.String]
        $BackupStoreProvider,

        [parameter(Mandatory = $false)]
        [System.String]
        $BackupLocation,

        [parameter(Mandatory = $true)]
		[System.Management.Automation.PSCredential]
        $PortalSiteAdministrator,

        [Parameter(Mandatory=$false)]
        [System.Management.Automation.PSCredential]
        $ContentDirectoryStorageAccountCredential,
        
        [Parameter(Mandatory=$false)]
        [System.String]
        $ContentDirectoryStorageContainerName,

        [parameter(Mandatory = $false)]
        [System.Boolean]
        $IncludeTileCache = $false,
        
        [parameter(Mandatory = $true)]
		[System.Management.Automation.PSCredential]
        $AzureBlobStorageCredentials,
        
        [parameter(Mandatory = $false)]
        [System.String]
        $AzureBlobStorageContainer = "arcgis-webgisdr-backup",

        [Parameter(Mandatory=$true)]
        [ValidateSet("Weekly","Daily")]
        [System.String]
        $BackupPolicyType,

        [Parameter(Mandatory=$true)]
        [System.String]
        $BackupRunTime,

        [Parameter(Mandatory=$false)]
        [System.String]
        $BackupRunTimeZone,

        [Parameter(Mandatory=$false)]
        [System.String]
        $BackupRunDays,

        [parameter(Mandatory = $false)]
        [System.Boolean]
		$DailyIncrementalBackupEnabled = $false,

        [parameter(Mandatory = $false)]
        [System.Boolean]
		$EnableDebugLogging = $false,
        
        [Parameter(Mandatory=$true)]
        [System.String]
        $ArcGISDeploymentVersion
    )
    Import-Module $PSScriptRoot\..\..\ArcGISUtility.psm1 -Verbose:$false

	$null
}

function Set-TargetResource
{
    [CmdletBinding()]
	[OutputType([System.Collections.Hashtable])]
	param
	(
        [parameter(Mandatory = $true)]
        [System.String]
        $SharedLocation,

        [parameter(Mandatory = $true)]
		[ValidateSet("FileSystem","Azure")]
        [System.String]
        $BackupStoreProvider,

        [parameter(Mandatory = $false)]
        [System.String]
        $BackupLocation,

        [parameter(Mandatory = $true)]
		[System.Management.Automation.PSCredential]
        $PortalSiteAdministrator,

        [Parameter(Mandatory=$false)]
        [System.Management.Automation.PSCredential]
        $ContentDirectoryStorageAccountCredential,
        
        [Parameter(Mandatory=$false)]
        [System.String]
        $ContentDirectoryStorageContainerName,

        [parameter(Mandatory = $false)]
        [System.Boolean]
        $IncludeTileCache = $false,
        
        [parameter(Mandatory = $true)]
		[System.Management.Automation.PSCredential]
        $AzureBlobStorageCredentials,
        
        [parameter(Mandatory = $false)]
        [System.String]
        $AzureBlobStorageContainer = "arcgis-webgisdr-backup",

        [Parameter(Mandatory=$true)]
        [ValidateSet("Weekly","Daily")]
        [System.String]
        $BackupPolicyType,

        [Parameter(Mandatory=$true)]
        [System.String]
        $BackupRunTime,

        [Parameter(Mandatory=$false)]
        [System.String]
        $BackupRunTimeZone,

        [Parameter(Mandatory=$false)]
        [System.String]
        $BackupRunDays,

        [parameter(Mandatory = $false)]
        [System.Boolean]
		$DailyIncrementalBackupEnabled = $false,

        [parameter(Mandatory = $false)]
        [System.Boolean]
		$EnableDebugLogging = $false,
        
        [Parameter(Mandatory=$true)]
        [System.String]
        $ArcGISDeploymentVersion
    )
    Import-Module $PSScriptRoot\..\..\ArcGISUtility.psm1 -Verbose:$false
    [System.Reflection.Assembly]::LoadWithPartialName("System.Web") | Out-Null
    $FQDN = Get-FQDN $env:COMPUTERNAME 

    $PortalInstallLocation = (Get-WmiObject -Class Win32_Product -Filter 'Name like "%Portal%"').InstallLocation
    $WebGISDRToolFolderLocation = "$($PortalInstallLocation)tools\webgisdr"
    $WebGISDRToolLocation = "$($WebGISDRToolFolderLocation)\webgisdr.bat"
    #$BackupPolicy = "Daily;11:30 AM;UTC"
    #$BackupPolicy = "Weekly;11:30 AM;UTC;Sunday"
    if($null -ne $BackupRunTimeZone -and $BackupRunTimeZone -ne ""){
        $oFromTimeZone = [System.TimeZoneInfo]::FindSystemTimeZoneById(([System.TimeZoneInfo]::Local).Id)
        $oToTimeZone = [System.TimeZoneInfo]::FindSystemTimeZoneById($BackupRunTimeZone)
        $utc = [System.TimeZoneInfo]::ConvertTimeToUtc($BackupRunTime, $oFromTimeZone)
        $newTime = [System.TimeZoneInfo]::ConvertTime($utc, $oToTimeZone)
        $BackupRunTime = $newTime.toString("hh:mm")
    }else{
        $BackupRunTime = ([datetime]$BackupRunTime).toString("hh:mm")
    }
    
    $FullBackupPropertiesFilePath = "$($SharedLocation)\mywebgis-f.properties"

    $hash = @{}
    $hash.Add("SHARED_LOCATION", $SharedLocation)
    $hash.Add("PORTAL_ADMIN_URL", "https://$($FQDN):7443/arcgis")
    $hash.Add("PORTAL_ADMIN_USERNAME", $PortalSiteAdministrator.UserName)
    $hash.Add("PORTAL_ADMIN_PASSWORD", $PortalSiteAdministrator.GetNetworkCredential().Password)
    $hash.Add("PORTAL_ADMIN_PASSWORD_ENCRYPTED", "false")
    $hash.Add("INCLUDE_SCENE_TILE_CACHES", (@('false', 'true')[$IncludeTileCache]))
    
    if($null -ne $ContentDirectoryStorageAccountCredential){
        $AccountName = $ContentDirectoryStorageAccountCredential.UserName
		$EndpointSuffix = ''
        $Pos = $ContentDirectoryStorageAccountCredential.UserName.IndexOf('.blob.')
        if($Pos -gt -1) {
            $AccountName = $ContentDirectoryStorageAccountCredential.UserName.Substring(0, $Pos)
			$EndpointSuffix = $ContentDirectoryStorageAccountCredential.UserName.Substring($Pos + 6) # Remove the hostname and .blob. suffix to get the storage endpoint suffix
			$hash.Add("PORTAL_BACKUP_BLOB_ACCOUNT_NAME", $AccountName)
            $hash.Add("PORTAL_BACKUP_BLOB_ACCOUNT_KEY", $ContentDirectoryStorageAccountCredential.GetNetworkCredential().Password)
            $hash.Add("PORTAL_BACKUP_BLOB_ACCOUNT_KEY_ENCRYPTED", "false")
            $hash.Add("PORTAL_BACKUP_BLOB_ACCOUNT_ENDPOINT_SUFFIX", $EndpointSuffix)
            $hash.Add("PORTAL_BACKUP_BLOB_CONTAINER_NAME", $ContentDirectoryStorageContainerName)
            $hash.Add("PORTAL_BACKUP_BLOB_ENDPOINT_URL", "https://$($ContentDirectoryStorageAccountCredential.UserName)")
        }else{
            throw "Error - Invalid Portal Content Directory Blob Storage Account"
        }
    }

    if($BackupStoreProvider -ieq "FileSystem"){
        $hash.Add("BACKUP_STORE_PROVIDER", "FileSystem")
        $hash.Add("BACKUP_LOCATION", $BackupLocation)
    }elseif($BackupStoreProvider -ieq "Azure"){
        $hash.Add("BACKUP_STORE_PROVIDER", "AzureBlob")
        $AccountName = $AzureBlobStorageCredentials.UserName
		$EndpointSuffix = ''
        $Pos = $AzureBlobStorageCredentials.UserName.IndexOf('.blob.')
        if($Pos -gt -1) {
            $AccountName = $AzureBlobStorageCredentials.UserName.Substring(0, $Pos)
            $EndpointSuffix = $AzureBlobStorageCredentials.UserName.Substring($Pos + 6) # Remove the hostname and .blob. suffix to get the storage endpoint suffix
            $hash.Add("AZURE_BLOB_ACCOUNT_NAME",$AccountName)
            $hash.Add("AZURE_BLOB_ACCOUNT_KEY",$AzureBlobStorageCredentials.GetNetworkCredential().Password)
            $hash.Add("AZURE_BLOB_ACCOUNT_KEY_ENCRYPTED","false")
            $hash.Add("AZURE_BLOB_ACCOUNT_ENDPOINT_SUFFIX", $EndpointSuffix)
            $hash.Add("AZURE_BLOB_CONTAINER_NAME",$AzureBlobStorageContainer)
            $hash.Add("AZURE_BLOB_ENDPOINT_URL", "https://$($AzureBlobStorageCredentials.UserName)")
        }else{
            throw "Error - Invalid Backup Blob Storage Account"
        }
    }
    $hash.Add("BACKUP_RESTORE_MODE","full")

    $FullBackupAction = New-ScheduledTaskAction -Execute $WebGISDRToolLocation -Argument "--export --file $FullBackupPropertiesFilePath"
    New-Item $FullBackupPropertiesFilePath -ItemType File -Force
    if($BackupPolicyType -ieq "Daily"){
        $hash.GetEnumerator() | % { "$($_.Name)=$($_.Value)" } | Out-File -Encoding Oem $FullBackupPropertiesFilePath
        $DailyTrigger = New-ScheduledTaskTrigger -Daily -At "$BackupRunTime"
        Register-ScheduledTask -Action $FullBackupAction -Trigger $DailyTrigger -TaskName "DailyArcGISBackupJob" -Description "Daily Backup Job of ArcGIS Deployment" -Verbose -User "System"
    }elseif($BackupPolicyType -ieq "Weekly"){
        $hash.GetEnumerator() | % { "$($_.Name)=$($_.Value)" } | Out-File -Encoding Oem $FullBackupPropertiesFilePath
        $FullBackupTrigger = New-ScheduledTaskTrigger -Weekly -DaysOfWeek $BackupRunDays -At "$BackupRunTime"
        Register-ScheduledTask -Action $FullBackupAction -Trigger $FullBackupTrigger -TaskName "WeeklyArcGISBackupJob" -Description "Weekly Backup Job of ArcGIS Deployment" -User "System"
       
        if($DailyIncrementalBackupEnabled){
            $hash.Remove("BACKUP_RESTORE_MODE")
            $hash.Add("BACKUP_RESTORE_MODE","incremental")
            $IncrementalBackupPropertiesFilePath = "$($SharedLocation)\mywebgis-i.properties"
            $hash.GetEnumerator() | % { "$($_.Name)=$($_.Value)" } | Out-File -Encoding Oem $IncrementalBackupPropertiesFilePath
            
            $IncrementalBackupAction = New-ScheduledTaskAction -Execute $WebGISDRToolLocation -Argument "--export --file $IncrementalBackupPropertiesFilePath"
            $IncrementalBackupRunDays = @('Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday') | ? { $BackupRunDays.split(',') -notcontains $_ }
            $IncrementalTrigger = New-ScheduledTaskTrigger -Weekly -DaysOfWeek $IncrementalBackupRunDays -At "$BackupRunTime"
            Register-ScheduledTask -Action $IncrementalBackupAction -Trigger $IncrementalTrigger -TaskName "DailyArcGISIncrementalBackupJob" -Description "Daily Incremental Backup Job of Weekly Backup of ArcGIS Deployment Job" -User "System"
        }
    }
}

function Test-TargetResource
{
    [CmdletBinding()]
    [OutputType([System.Boolean])]
    param
    (
        [parameter(Mandatory = $true)]
        [System.String]
        $SharedLocation,

        [parameter(Mandatory = $true)]
		[ValidateSet("FileSystem","Azure")]
        [System.String]
        $BackupStoreProvider,

        [parameter(Mandatory = $false)]
        [System.String]
        $BackupLocation,

        [parameter(Mandatory = $true)]
		[System.Management.Automation.PSCredential]
        $PortalSiteAdministrator,

        [Parameter(Mandatory=$false)]
        [System.Management.Automation.PSCredential]
        $ContentDirectoryStorageAccountCredential,
        
        [Parameter(Mandatory=$false)]
        [System.String]
        $ContentDirectoryStorageContainerName,

        [parameter(Mandatory = $false)]
        [System.Boolean]
        $IncludeTileCache = $false,
        
        [parameter(Mandatory = $true)]
		[System.Management.Automation.PSCredential]
        $AzureBlobStorageCredentials,
        
        [parameter(Mandatory = $false)]
        [System.String]
        $AzureBlobStorageContainer = "arcgis-webgisdr-backup",

        [Parameter(Mandatory=$true)]
        [ValidateSet("Weekly","Daily")]
        [System.String]
        $BackupPolicyType,

        [Parameter(Mandatory=$true)]
        [System.String]
        $BackupRunTime,

        [Parameter(Mandatory=$false)]
        [System.String]
        $BackupRunTimeZone,

        [Parameter(Mandatory=$false)]
        [System.String]
        $BackupRunDays,

        [parameter(Mandatory = $false)]
        [System.Boolean]
		$DailyIncrementalBackupEnabled = $false,

        [parameter(Mandatory = $false)]
        [System.Boolean]
		$EnableDebugLogging = $false,
        
        [Parameter(Mandatory=$true)]
        [System.String]
        $ArcGISDeploymentVersion
    )
    [System.Reflection.Assembly]::LoadWithPartialName("System.Web") | Out-Null
    Import-Module $PSScriptRoot\..\..\ArcGISUtility.psm1 -Verbose:$false

    #$PortalInstallLocation = (Get-WmiObject -Class Win32_Product -Filter 'Name like "%Portal%"').InstallLocation
    $false
}

Export-ModuleMember -Function *-TargetResource