function Get-TargetResource
{
    [CmdletBinding()]
	[OutputType([System.Collections.Hashtable])]
	param
	(
        [Parameter(Mandatory=$true)]
        [System.String]
        $DataStoreType,

        [Parameter(Mandatory=$true)]
        [System.String]
        $BackupName,

        [Parameter(Mandatory=$true)]
        [System.String]
        $BackupLocation,

        [parameter(Mandatory = $true)]
        [System.String]
		[ValidateSet("Azure","FileSystem")]
        $BackupStoreProvider,
        
        [parameter(Mandatory = $false)]
		[System.Management.Automation.PSCredential]
		$BackupLocationCredential,

        [Parameter(Mandatory=$true)]
        [ValidateSet("Weekly","Daily")]
        [System.String]
        $BackupPolicyType,

        [Parameter(Mandatory=$true)]
        [System.String]
        $BackupRunTime,

        [Parameter(Mandatory=$false)]
        [System.String]
        $BackupRunTimeZone,

        [Parameter(Mandatory=$false)]
        [System.String]
        $BackupRunDays,

        [parameter(Mandatory = $false)]
        [System.Boolean]
		$DailyIncrementalBackupEnabled = $false,

        [parameter(Mandatory = $false)]
        [System.Boolean]
		$EnableDebugLogging = $false,
        
        [Parameter(Mandatory=$true)]
        [System.String]
        $ArcGISDeploymentVersion
    )
    Import-Module $PSScriptRoot\..\..\ArcGISUtility.psm1 -Verbose:$false

	$null
}

function Set-TargetResource
{
    [CmdletBinding()]
	[OutputType([System.Collections.Hashtable])]
	param
	(
        [Parameter(Mandatory=$true)]
        [System.String]
        $DataStoreType,

        [Parameter(Mandatory=$true)]
        [System.String]
        $BackupName,

        [Parameter(Mandatory=$true)]
        [System.String]
        $BackupLocation,

        [parameter(Mandatory = $true)]
        [System.String]
		[ValidateSet("Azure","FileSystem")]
        $BackupStoreProvider,
        
        [parameter(Mandatory = $false)]
		[System.Management.Automation.PSCredential]
		$BackupLocationCredential,

        [Parameter(Mandatory=$true)]
        [ValidateSet("Weekly","Daily")]
        [System.String]
        $BackupPolicyType,

        [Parameter(Mandatory=$true)]
        [System.String]
        $BackupRunTime,

        [Parameter(Mandatory=$false)]
        [System.String]
        $BackupRunTimeZone,

        [Parameter(Mandatory=$false)]
        [System.String]
        $BackupRunDays,

        [parameter(Mandatory = $false)]
        [System.Boolean]
		$DailyIncrementalBackupEnabled = $false,

        [parameter(Mandatory = $false)]
        [System.Boolean]
        $EnableDebugLogging = $false,
        
        [Parameter(Mandatory=$true)]
        [System.String]
        $ArcGISDeploymentVersion
    )

    Import-Module $PSScriptRoot\..\..\ArcGISUtility.psm1 -Verbose:$false
    [System.Reflection.Assembly]::LoadWithPartialName("System.Web") | Out-Null
    $FQDN = Get-FQDN $env:COMPUTERNAME 
    $RegKey = Get-EsriRegistryKeyForService -ServiceName 'ArcGIS Data Store'
    $InstallDir = (Get-ItemProperty -Path $RegKey -ErrorAction Ignore).InstallDir
    Write-Verbose "Install Dir for 'ArcGIS Data Store' is $InstallDir"
    if($InstallDir) 
    {
        $InstallDir = $InstallDir.TrimEnd('\')
        if(Test-Path $InstallDir) 
        {
            $result = $false
            $ExecPath = Join-Path $InstallDir '\\tools\\configurebackuplocation.bat'
            $Arguments = "--operation register --store $DataStoreType --prompt no --location "
            if($BackupStoreProvider -eq "Azure")
            {
                $Pos = $BackupLocationCredential.UserName.IndexOf('.blob.')
                if($Pos -gt -1) 
                {
                    $EndpointSuffix = $BackupLocationCredential.UserName.Substring($Pos + 6)
                    $ArcGISDeploymentVersionArray = $ArcGISDeploymentVersion.Split('.')
                    if(($ArcGISDeploymentVersionArray[1] -ge 7) -or (($ArcGISDeploymentVersionArray[1] -le 6) -and ($EndpointSuffix -eq "core.windows.net"))){
                        $BackupLocationUserName = $BackupLocationCredential.UserName.Substring(0, $Pos)
                        $BackupLocationPassword = $BackupLocationCredential.GetNetworkCredential().Password
                        $Arguments += "type=azure;location=$BackupLocation;name=$BackupName;username=$BackupLocationUserName;password=$BackupLocationPassword"
                        if($ArcGISDeploymentVersionArray[1] -ge 7){
                            $Arguments += ";endpoint=$EndpointSuffix"
                        }
                    }else{
                        throw "Error - Backups to Cloud Storage with endpoint suffix $EndpointSuffix is not supported for ArcGIS Enterprise 10.6.1 and below"
                    }
                }
                else
                {
                    throw "Error - Invalid Backup Blob Storage Account"
                }   
            }
            elseif($BackupStoreProvider -eq "FileSystem"){
                $Arguments = "type=fs;location=$BackupLocation;name=$BackupName"
            }
            $psi = New-Object System.Diagnostics.ProcessStartInfo
            $psi.FileName = $ExecPath
            $psi.Arguments = $Arguments
            $psi.UseShellExecute = $false #start the process from it's own executable file    
            $psi.RedirectStandardOutput = $true #enable the process to read from standard output
            $psi.RedirectStandardError = $true #enable the process to read from standard error
            $psi.EnvironmentVariables["AGSDATASTORE"] = [environment]::GetEnvironmentVariable("AGSDATASTORE","Machine")
            
            $p = [System.Diagnostics.Process]::Start($psi)
            $p.WaitForExit()
            $op = $p.StandardOutput.ReadToEnd()
            if($op -and $op.Length -gt 0) {
                Write-Verbose "Output of execution:- $op"
            }
            $err = $p.StandardError.ReadToEnd()
            
            if($p.ExitCode -eq 0) {                    
                Write-Verbose "Configure Backup Location confiured successfully"
                $result = $true
            }else {
                Write-Verbose "Process exit code:- $($p.ExitCode) $err"
            }

            if($result){
                if($null -ne $BackupRunTimeZone -and $BackupRunTimeZone -ne ""){
                    $oFromTimeZone = [System.TimeZoneInfo]::FindSystemTimeZoneById(([System.TimeZoneInfo]::Local).Id)
                    $oToTimeZone = [System.TimeZoneInfo]::FindSystemTimeZoneById($BackupRunTimeZone)
                    $utc = [System.TimeZoneInfo]::ConvertTimeToUtc($BackupRunTime, $oFromTimeZone)
                    $newTime = [System.TimeZoneInfo]::ConvertTime($utc, $oToTimeZone)
                    $BackupRunTime = $newTime.toString("hh:mm:ss")
                }else{
                    $BackupRunTime = ([datetime]$BackupRunTime).toString("hh:mm:ss")
                }

                
                if($BackupPolicyType -ieq "Daily" -or ( ($BackupPolicyType -ieq "Weekly") -and $DailyIncrementalBackupEnabled)){
                    $ExecPath = Join-Path $InstallDir '\\tools\\updatebackupschedule.bat'
                    $Arguments = "--store $DataStoreType --starttime $BackupRunTime --frequency 1"

                    $psi = New-Object System.Diagnostics.ProcessStartInfo
                    $psi.FileName = $ExecPath
                    $psi.Arguments = $Arguments
                    $psi.UseShellExecute = $false #start the process from it's own executable file    
                    $psi.RedirectStandardOutput = $true #enable the process to read from standard output
                    $psi.RedirectStandardError = $true #enable the process to read from standard error
                    $psi.EnvironmentVariables["AGSDATASTORE"] = [environment]::GetEnvironmentVariable("AGSDATASTORE","Machine")
                    
                    $p = [System.Diagnostics.Process]::Start($psi)
                    $p.WaitForExit()
                    $op = $p.StandardOutput.ReadToEnd()
                    if($op -and $op.Length -gt 0) {
                        Write-Verbose "Output of execution:- $op"
                    }
                    $err = $p.StandardError.ReadToEnd()
                    
                    if($p.ExitCode -eq 0) {                    
                        Write-Verbose "Backup Schedule confiured successfully"
                        $result = $true
                    }else {
                        Write-Verbose "Process exit code:- $($p.ExitCode) $err"
                    }
                    #updatebackupschedule [--store relational|tileCache|spatiotemporal] [--starttime <local server time>] --frequency <number of days>
                    #$DailyTrigger = New-ScheduledTaskTrigger -Daily -At "$BackupRunTime"
                    #Register-ScheduledTask -Action $FullBackupAction -Trigger $DailyTrigger -TaskName "DailyArcGISDatastoreBackupJob-$DataStoreType" -Description "Daily Backup Job of ArcGIS $DataStoreType Datastore " -Verbose -User "System"
                }else{
                    $MannualBackupToolLocation = Join-Path $InstallDir '\\tools\\backupdatastore.bat'
                    $FullBackupAction = New-ScheduledTaskAction -Execute $MannualBackupToolLocation -Argument "--store $DataStoreType --prompt no --location type=azure;location=$BackupLocation"
                    $WeeklyTrigger = New-ScheduledTaskTrigger -Weekly -DaysOfWeek $BackupRunDays -At "$BackupRunTime"
                    Register-ScheduledTask -Action $FullBackupAction -Trigger $WeeklyTrigger -TaskName "WeeklyArcGISDatastoreBackupJob-$DataStoreType" -Description "Weekly Backup Job of ArcGIS $DataStoreType Datastore" -Verbose -User "System"
                }
            }
        }
    }
}

function Test-TargetResource
{
    [CmdletBinding()]
	[OutputType([System.Collections.Hashtable])]
	param
	(
        [Parameter(Mandatory=$true)]
        [System.String]
        $DataStoreType,

        [Parameter(Mandatory=$true)]
        [System.String]
        $BackupName,

        [Parameter(Mandatory=$true)]
        [System.String]
        $BackupLocation,

        [parameter(Mandatory = $true)]
        [System.String]
		[ValidateSet("Azure","FileSystem")]
        $BackupStoreProvider,
        
        [parameter(Mandatory = $false)]
		[System.Management.Automation.PSCredential]
		$BackupLocationCredential,

        [Parameter(Mandatory=$true)]
        [ValidateSet("Weekly","Daily")]
        [System.String]
        $BackupPolicyType,

        [Parameter(Mandatory=$true)]
        [System.String]
        $BackupRunTime,

        [Parameter(Mandatory=$false)]
        [System.String]
        $BackupRunTimeZone,

        [Parameter(Mandatory=$false)]
        [System.String]
        $BackupRunDays,

        [parameter(Mandatory = $false)]
        [System.Boolean]
		$DailyIncrementalBackupEnabled = $false,

        [parameter(Mandatory = $false)]
        [System.Boolean]
		$EnableDebugLogging = $false,
        
        [Parameter(Mandatory=$true)]
        [System.String]
        $ArcGISDeploymentVersion
    )

    Import-Module $PSScriptRoot\..\..\ArcGISUtility.psm1 -Verbose:$false

    $false
}

Export-ModuleMember -Function *-TargetResource