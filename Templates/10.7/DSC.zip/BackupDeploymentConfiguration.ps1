Configuration BackupDeploymentConfiguration{
    
    param(
        [Parameter(Mandatory=$true)]
        [System.String]
        $ExternalDNSHostName,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullorEmpty()]
        [System.Management.Automation.PSCredential]
        $SiteAdministratorCredential,

        [Parameter(Mandatory=$true)]
        [System.Boolean]
        $HasPortal,

        [Parameter(Mandatory=$true)]
        [System.Boolean]
        $HasBDS,
        
        [Parameter(Mandatory=$true)]
        [System.Management.Automation.PSCredential]
        $BackupStorageAccountCredential,

        [Parameter(Mandatory=$false)]
        [System.String]
        $UseCloudStorageForContentDirectory = $false,
        
        [Parameter(Mandatory=$false)]
        [System.Management.Automation.PSCredential]
        $ContentDirectoryStorageAccountCredential,

        [Parameter(Mandatory=$false)]
        [System.Management.Automation.PSCredential]
        $ContentDirectoryStorageContainerName,
        
        [Parameter(Mandatory=$true)]
        [System.String]
        $FileShareMachineName,
        
        [Parameter(Mandatory=$false)]
        [System.String]
        $FileShareName = 'fileshare',

        [Parameter(Mandatory=$true)]
        [System.String]
        $BackupPolicyType,

        [Parameter(Mandatory=$true)]
        [System.String]
        $BackupRunTime,

        [Parameter(Mandatory=$false)]
        [System.String]
        $BackupRunTimeZone = $null,

        [Parameter(Mandatory=$true)]
        [System.String]
        $BackupRunDays = $null,

        [Parameter(Mandatory=$false)]
        [System.String]
        $DebugMode,

        [Parameter(Mandatory=$true)]
        [System.String]
        $ArcGISDeploymentVersion 
    )

    Import-DscResource -Name ArcGIS_WebgisdrBackup
    Import-DscResource -Name ArcGIS_DatastoreBackup

    Node localhost
    {
        if($HasPortal){
            
            if($UseCloudStorageForContentDirectory -ieq 'True'){
                $Namespace = $ExternalDNSHostName
                $Pos = $Namespace.IndexOf('.')
                if($Pos -gt 0) { $Namespace = $Namespace.Substring(0, $Pos) }        
                $Namespace = [System.Text.RegularExpressions.Regex]::Replace($Namespace, '[\W]', '') # Sanitize
                $ContentDirectoryCloudContainerName = "arcgis-portal-content-$($Namespace)"
            }

            ArcGIS_WebgisdrBackup WebgisdrBackup{
                SharedLocation                  = "\\\\$FileShareMachineName\\$FileShareName\\backup"
                BackupStoreProvider             = "Azure"
                PortalSiteAdministrator         = $SiteAdministratorCredential 
                ContentDirectoryStorageAccountCredential = if($UseCloudStorageForContentDirectory -ieq 'True'){$ContentDirectoryStorageAccountCredential}else{$null}
                ContentDirectoryStorageContainerName = if($UseCloudStorageForContentDirectory -ieq 'True'){$ContentDirectoryCloudContainerName}else{$null}
                IncludeTileCache                = $True
                AzureBlobStorageCredentials     = $BackupStorageAccountCredential
                AzureBlobStorageContainer       = "arcgis-webgisdr-backup"
                BackupPolicyType                = $BackupPolicyType
                BackupRunTime                   = $BackupRunTime
                BackupRunTimeZone               = $BackupRunTimeZone
                BackupRunDays                   = $BackupRunDays
                DailyIncrementalBackupEnabled   = $True
                EnableDebugLogging              = if($DebugMode -ieq "true"){ $true}else{$false}
                ArcGISDeploymentVersion         = $ArcGISDeploymentVersion
            }
        }

        if($HasBDS){
            ArcGIS_DatastoreBackup SpatioTemporalBackup{    
                DataStoreType                   = "SpatioTemporal"
                BackupStoreProvider             = "Azure"
                BackupName                      = "bdsBackup"
                BackupLocation                  = "arcgis-spatiotemporal-backup"
                BackupLocationCredential        = $BackupLocationCredential
                BackupPolicyType                = $BackupPolicyType
                BackupRunTime                   = $BackupRunTime
                BackupRunTimeZone               = $BackupRunTimeZone
                BackupRunDays                   = $BackupRunDays
                DailyIncrementalBackupEnabled   = $True
                EnableDebugLogging              = if($DebugMode -ieq "true"){ $true}else{$false}
                ArcGISDeploymentVersion         = $ArcGISDeploymentVersion
            }
        } 
    }
}